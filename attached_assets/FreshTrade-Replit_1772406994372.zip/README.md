# FreshTrade Distribution

Meat & seafood distribution management system.

## Replit Setup

1. Create a new Replit → choose **HTML/CSS/JS** template
2. Delete the default files (index.html, style.css, script.js)
3. Upload these files: `index.html`, `app.js`, `.replit`, `replit.nix`, `package.json`
4. Click **Run**

The app will be live at your Replit URL.

## Files

- `index.html` — Shell page that loads React + the app
- `app.js` — Pre-compiled application (no build step needed)
- `.replit` — Replit run configuration
- `replit.nix` — Nix environment (Node.js)
- `package.json` — npm config

## Notes

- Data is stored in the browser's IndexedDB (persists per device/browser)
- No server or database required — runs entirely client-side
- Print features use the browser's native print dialog
